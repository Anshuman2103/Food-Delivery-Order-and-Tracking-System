#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure representing a Food Delivery Order
typedef struct {
    int order_id;
    char customer_name[50];
    char restaurant[50];
    char status[30];          // e.g., "Placed", "Preparing", "Out for Delivery", "Delivered"
    int delivery_time;        // Actual delivery time in minutes
    float amount;             // Order total value in INR/USD
    float bonus_or_penalty;   // +Bonus for fast delivery, -Penalty for delay
} Order;

// Function Prototypes
void addOrder(Order **orders, int *count, int *capacity);
void updateOrderStatus(Order *orders, int count);
void viewOrders(const Order *orders, int count);
void generateReport(const Order *orders, int count);
void saveToFile(const Order *orders, int count, const char *filename);
int loadFromFile(Order **orders, int *count, int *capacity, const char *filename);

int main() {
    Order *orders = NULL;
    int count = 0;
    int capacity = 2; // Initial dynamic array capacity
    const char *filename = "delivery_history.dat";
    int choice;

    // Allocate initial memory dynamically using pointers (CO4)
    orders = (Order *)malloc(capacity * sizeof(Order));
    if (orders == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    // Load existing records from disk if available (File Handling)
    if (loadFromFile(&orders, &count, &capacity, filename)) {
        printf("Loaded %d previous orders from %s.\n", count, filename);
    }

    do {
        printf("\n============================================\n");
        printf("   FOOD DELIVERY ORDER & TRACKING SYSTEM    \n");
        printf("============================================\n");
        printf("1. Place New Order\n");
        printf("2. Update Order Status & Calculate Bonus/Delay\n");
        printf("3. View All Orders / Delivery History\n");
        printf("4. Generate Performance & Revenue Report\n");
        printf("5. Save & Exit\n");
        printf("Enter your choice: ");
        
        if (scanf("%d", &choice) != 1) {
            while (getchar() != '\n'); // Clear invalid input
            choice = 0;
        }

        switch (choice) {
            case 1:
                addOrder(&orders, &count, &capacity);
                break;
            case 2:
                updateOrderStatus(orders, count);
                break;
            case 3:
                viewOrders(orders, count);
                break;
            case 4:
                generateReport(orders, count);
                break;
            case 5:
                saveToFile(orders, count, filename);
                printf("Data saved successfully. Exiting system...\n");
                break;
            default:
                printf("Invalid choice! Please select a number between 1 and 5.\n");
        }
    } while (choice != 5);

    // Free allocated memory
    free(orders);
    return 0;
}

// CO1 & CO4: Add a new order with automatic dynamic array resizing (realloc)
void addOrder(Order **orders, int *count, int *capacity) {
    if (*count == *capacity) {
        *capacity *= 2;
        Order *temp = (Order *)realloc(*orders, (*capacity) * sizeof(Order));
        if (temp == NULL) {
            printf("Error: Unable to expand memory!\n");
            return;
        }
        *orders = temp;
    }

    Order *newOrder = &((*orders)[*count]);
    newOrder->order_id = 1001 + *count; // Auto-generate sequential Order ID

    getchar(); // Consume trailing newline
    printf("Enter Customer Name: ");
    fgets(newOrder->customer_name, sizeof(newOrder->customer_name), stdin);
    newOrder->customer_name[strcspn(newOrder->customer_name, "\n")] = '\0';

    printf("Enter Restaurant Name: ");
    fgets(newOrder->restaurant, sizeof(newOrder->restaurant), stdin);
    newOrder->restaurant[strcspn(newOrder->restaurant, "\n")] = '\0';

    printf("Enter Order Amount (Rs.): ");
    scanf("%f", &newOrder->amount);

    strcpy(newOrder->status, "Placed");
    newOrder->delivery_time = 0;
    newOrder->bonus_or_penalty = 0.0;

    (*count)++;
    printf("Order #%d placed successfully!\n", newOrder->order_id);
}

// CO2: Update status and apply decision logic for bonuses/penalties
void updateOrderStatus(Order *orders, int count) {
    if (count == 0) {
        printf("No orders available to update.\n");
        return;
    }

    int id, found = 0, statusChoice;
    printf("Enter Order ID to update: ");
    scanf("%d", &id);

    for (int i = 0; i < count; i++) {
        if (orders[i].order_id == id) {
            found = 1;
            printf("\nCurrent Status for Order #%d (%s): %s\n", 
                   orders[i].order_id, orders[i].customer_name, orders[i].status);
            printf("Select New Status:\n");
            printf("1. Preparing\n2. Out for Delivery\n3. Delivered\nChoice: ");
            scanf("%d", &statusChoice);

            if (statusChoice == 1) {
                strcpy(orders[i].status, "Preparing");
            } else if (statusChoice == 2) {
                strcpy(orders[i].status, "Out for Delivery");
            } else if (statusChoice == 3) {
                strcpy(orders[i].status, "Delivered");
                printf("Enter total delivery time taken (in minutes): ");
                scanf("%d", &orders[i].delivery_time);

                // Decision logic: SLA is 30 mins
                if (orders[i].delivery_time <= 25) {
                    orders[i].bonus_or_penalty = 50.0; // Speed bonus
                    printf("Fast Delivery! Rider earned a Rs. 50.00 bonus.\n");
                } else if (orders[i].delivery_time > 40) {
                    orders[i].bonus_or_penalty = -40.0; // Delay penalty
                    printf("Delayed Delivery (>40 mins)! Rs. 40.00 penalty applied.\n");
                } else {
                    orders[i].bonus_or_penalty = 0.0;
                    printf("Delivered on standard time window.\n");
                }
            } else {
                printf("Invalid status selection.\n");
                return;
            }
            printf("Order #%d status updated to '%s'.\n", orders[i].order_id, orders[i].status);
            break;
        }
    }

    if (!found) {
        printf("Order ID #%d not found.\n", id);
    }
}

// CO3: View delivery history by iterating through the structure array
void viewOrders(const Order *orders, int count) {
    if (count == 0) {
        printf("No order records found.\n");
        return;
    }

    printf("\n-------------------------------------------------------------------------------------------------\n");
    printf("%-8s %-18s %-18s %-18s %-10s %-10s %-10s\n", 
           "ID", "Customer", "Restaurant", "Status", "Time(m)", "Amount", "Bonus/Pen");
    printf("-------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        printf("%-8d %-18s %-18s %-18s %-10d %-10.2f %+10.2f\n",
               orders[i].order_id,
               orders[i].customer_name,
               orders[i].restaurant,
               orders[i].status,
               orders[i].delivery_time,
               orders[i].amount,
               orders[i].bonus_or_penalty);
    }
    printf("-------------------------------------------------------------------------------------------------\n");
}

// CO3 & CO5: Generate financial and operational performance reports
void generateReport(const Order *orders, int count) {
    if (count == 0) {
        printf("No data available to generate report.\n");
        return;
    }

    int deliveredCount = 0, totalDeliveryTime = 0, delayedCount = 0;
    float totalRevenue = 0.0, netAdjustments = 0.0;

    for (int i = 0; i < count; i++) {
        totalRevenue += orders[i].amount;
        if (strcmp(orders[i].status, "Delivered") == 0) {
            deliveredCount++;
            totalDeliveryTime += orders[i].delivery_time;
            netAdjustments += orders[i].bonus_or_penalty;
            if (orders[i].delivery_time > 40) {
                delayedCount++;
            }
        }
    }

    float avgTime = (deliveredCount > 0) ? (float)totalDeliveryTime / deliveredCount : 0.0;

    printf("\n================ PERFORMANCE & REVENUE REPORT ================\n");
    printf("Total Orders Placed      : %d\n", count);
    printf("Total Delivered Orders   : %d\n", deliveredCount);
    printf("Pending/Active Orders    : %d\n", count - deliveredCount);
    printf("Delayed Orders (>40 min) : %d\n", delayedCount);
    printf("Average Delivery Time    : %.2f minutes\n", avgTime);
    printf("Gross Order Revenue      : Rs. %.2f\n", totalRevenue);
    printf("Net Rider Bonus/Penalty  : Rs. %+.2f\n", netAdjustments);
    printf("==============================================================\n");
}

// File Handling: Persist data to disk
void saveToFile(const Order *orders, int count, const char *filename) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL) {
        printf("Error opening file for saving!\n");
        return;
    }
    fwrite(&count, sizeof(int), 1, fp);
    fwrite(orders, sizeof(Order), count, fp);
    fclose(fp);
}

// File Handling: Retrieve persisted data from disk
int loadFromFile(Order **orders, int *count, int *capacity, const char *filename) {
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL) {
        return 0; // File doesn't exist yet
    }

    int savedCount = 0;
    if (fread(&savedCount, sizeof(int), 1, fp) != 1 || savedCount <= 0) {
        fclose(fp);
        return 0;
    }

    if (savedCount > *capacity) {
        *capacity = savedCount;
        Order *temp = (Order *)realloc(*orders, (*capacity) * sizeof(Order));
        if (temp == NULL) {
            fclose(fp);
            return 0;
        }
        *orders = temp;
    }

    *count = fread(*orders, sizeof(Order), savedCount, fp);
    fclose(fp);
    return 1;
}